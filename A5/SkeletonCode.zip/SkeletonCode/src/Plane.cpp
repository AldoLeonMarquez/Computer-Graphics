#include "Plane.h"


Plane::Plane()
{
}

Plane::~Plane()
{
}

