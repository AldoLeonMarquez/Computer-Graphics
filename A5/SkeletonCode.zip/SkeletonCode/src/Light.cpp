#include "Light.h"

Light::Light(void)
{
}

Light::~Light(void)
{
}
