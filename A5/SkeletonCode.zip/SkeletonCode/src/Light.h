#pragma once

class Light
{
public:
	Light();
	~Light();

private:

};
