#pragma once

class Shape
{
public:
	Shape(void);
	~Shape(void);

private:
	
};
