#pragma once
#include "Shape.h"

class Plane :
	public Shape
{
public:
	Plane();
	~Plane();

private:

};
