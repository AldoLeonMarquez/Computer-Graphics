#include "Shape.h"

Shape::Shape(void)
{
}

Shape::~Shape(void)
{
}

