#pragma once
#include <glm/glm.hpp>
class Light
{
public:
	Light() {};
	~Light() {};
	glm::vec3 Position;
	glm::vec3 Color;

private:

};
