Full Implementation, 

No Bonuses;

I ended up writing directly to the frame Buffer, I could figure out what was going on for hours until i realize either the,
memset or the access to the renderImage array was not working, i would have finish on time(unlucky)

The Progam takes around 10 seconds to complete in my laptop

For the most part I didnt code much inside the cpp files so the ones that i didnt use at all i didnt include them

The attachment is the render in 1440p resolution

