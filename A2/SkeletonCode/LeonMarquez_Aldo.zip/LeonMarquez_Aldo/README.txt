Every section of the assigment was implemented.

I Added a reset button fot the camara, use the space bar.

The Rotation matrix is a bit sensitive, easier to use with movements as vertical or as horizontal as possible. 