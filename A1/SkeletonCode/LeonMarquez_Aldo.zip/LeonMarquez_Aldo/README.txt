Every section of the assigment was implemented.

The circle brush and the spray were also implemented: 

Circle brush: to alternate between shapes, press "b" case sensitive in the keyboard. 

Spray brush: to activate the spray brush press "r" case sensitive om the keyboard.