Every setion implemented, 

some artifacts appear when the camara is on top of the bunny, 

mode two works like a toggle when CPU render is selected;

I implemented the argument file name, need  the sufix "cpp" to work, enter on debug tab on project properties 