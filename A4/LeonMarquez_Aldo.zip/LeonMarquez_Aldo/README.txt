Every setion implemented, 

each shader named: shader,shader1,shader2,shader3 for frag and vert

Bonus Implemented too, I made a separate shader (Phong) that can be accessed by pressing '4'.
For it I defined the angle of the cone as 70 degrees and its alpha as 40.

